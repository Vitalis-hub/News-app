# Missing Examples

Below lists each of the issing examples and why it is not currently added.

 - Chef (takes > 60 seconds to run)
 - Puppet (takes > 60 seconds to run)
 - Manage resolve.conf (lxd backend overrides changes)
 - Adding a yum repository (need centos system)
 - Register RedHat Subscription (need centos system + subscription)
 - Adjust mount points mounted (need multiple disks)
 - Call a url when finished (need end point)
 - Reboot/poweroff when finished (how to test)
 - Disk setup (need multiple disks)

# vi: ts=4 expandtab
